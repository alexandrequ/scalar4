This is the source code that was used to build the "PIC16F1459_LowPinCountUSBDevKit_HIDPnPDemo.hex"
image, which is the default firmwage that should come pre-programmed on the microcontroller when the
demo board is shipped from the factory.

It is NOT recommended to use this source code for developing a new application, as this source code
is an archive and normally will not be updated or modified with the rest of the MLA source code.  Instead,
when developing a new application, it is recommended to start from the most relevant demo project
from the non-archived main MLA code base.