This is both the out of box demo firmware source code.  The same hex file
output is also used as the same PIC16F1459_LowPinCountUSBDevKit_HIDPnPDemo.hex
file that is used for the production test procedure tests for the demo board.

This code is based on a slightly upgraded version of the MCHPFSUSB Framework v2.9j.
This firmware primarily implements the standard HID custom demo, but with slight
changes (such as UART string printing for the production test procedures).