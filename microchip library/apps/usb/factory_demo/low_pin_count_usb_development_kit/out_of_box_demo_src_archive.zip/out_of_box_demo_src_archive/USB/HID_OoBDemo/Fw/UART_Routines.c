/********************************************************************
 FileName:	UART_Routines.c
 Dependencies:  See INCLUDES section
 Processor:	PIC18 or PIC16 Enhanced Core Microcontrollers
 Hardware:	PIC18 or PIC16 with UART connection
 Complier:  Microchip C18 (for PIC18) or XC8 (ex: for PIC16 or PIC18)
 Company:	Microchip Technology, Inc.

 Software License Agreement:

 The software supplied herewith by Microchip Technology Incorporated
 (the "Company") for its PIC(R) Microcontroller is intended and
 supplied to you, the Company's customer, for use solely and
 exclusively on Microchip PIC Microcontroller products. The
 software is owned by the Company and/or its supplier, and is
 protected under applicable copyright laws. All rights are reserved.
 Any use in violation of the foregoing restrictions may subject the
 user to criminal sanctions under applicable laws, as well as to
 civil liability for the breach of the terms and conditions of this
 license.

 THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,
 WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.

********************************************************************
 File Description:

 Change History:
  Rev   Description
  ----  -----------------------------------------
  1.0   Initial version.
********************************************************************/

/** INCLUDES *******************************************************/
#if defined(__18CXX)
#include <p18cxxx.h>
#else
#include <xc.h>
#endif
#include "GenericTypeDefs.h"
#include <stdint.h>
#include <string.h>
#include "UART_Routines.h"


#ifdef __DEBUG_UART //Should be defined in "UART_Routines.h" if it is defined.

/** DEFINITIONS ****************************************************/
#if defined(USE_UART1)
    #define TXREG_X     TXREG
    #define RCREG_X     RCREG
    #define TRMT_BIT    TXSTAbits.TRMT
    #define RECEIVE_BYTE_AVAILABLE_FLAG PIR1bits.RCIF
    #define OERR_BIT    RCSTAbits.OERR
#else
    #define TXREG_X TXREG2
    #define RCREG_X RCREG2
    #define TRMT_BIT    TXSTA2bits.TRMT
    #define RECEIVE_BYTE_AVAILABLE_FLAG PIR3bits.RC2IF      
    #define OERR_BIT    RCSTA2bits.OERR
#endif

#if defined(__18CXX)
    #define ImprovedNop()   {DummyChar++;}
#else
    #define ImprovedNop()   Nop()
#endif
/** VARIABLES ******************************************************/
#if defined(__18CXX)
#pragma idata
#endif
BOOL UARTInitialized = FALSE;
uint16_t BytesInBuffer;
uint8_t* pWritePointer;
uint8_t* pReadPointer;
uint8_t UARTReceiveBuffer[UART_RECEIVE_CIRCULAR_BUFFER_DEPTH];
//uint16_t LostDataBytes;

#if defined(__18CXX)
#pragma udata
BYTE DummyChar;
#endif




/** CODE **********************************************************/
#if defined(__18CXX)
#pragma code
#endif

#if defined(_PIC14E)
    #define SPBRG SPBRGL
#endif

void UARTInit(void)
{
    TX_LAT = 1;
    TX_TRIS = 0;
    RX_TRIS = 1;
    mInitRXDigital();
    mInitUartPPS();
    
    //Initialize UART1 module
    #if defined(USE_UART1)
    TXSTA = 0x24;       //8-bit, TX enabled, async mode, BRGH = 1
    RCSTA = 0x10;       //8-bit, RX enabled, module still off
    BAUDCON = 0x08;     //16-bit baud gen, no RX or TX inversion
    SPBRG = ((CLOCK_FREQ/(4u*DESIRED_BAUD_RATE)) - 1u);
    SPBRGH = (WORD)((CLOCK_FREQ/(4u*DESIRED_BAUD_RATE)) - 1u) >> 8;
    RCSTAbits.SPEN = 1; //Enable UART module
    #endif
    
    #if defined(USE_UART2)
    TXSTA2 = 0x24;       //8-bit, TX enabled, async mode, BRGH = 1
    RCSTA2 = 0x10;       //8-bit, RX enabled, module still off
    BAUDCON2 = 0x08;     //16-bit baud gen, no RX or TX inversion
    SPBRG2 = ((CLOCK_FREQ/(4u*DESIRED_BAUD_RATE)) - 1u);
    SPBRGH2 = (WORD)((CLOCK_FREQ/(4u*DESIRED_BAUD_RATE)) - 1u) >> 8;
    RCSTA2bits.SPEN = 1; //Enable UART module
    #endif
    ImprovedNop();
    ImprovedNop(); 
    
    //Initialize state tracking variables
    BytesInBuffer = 0;
    pWritePointer = &UARTReceiveBuffer[0];
    pReadPointer = &UARTReceiveBuffer[0];
    //LostDataBytes = 0;
    UARTInitialized = TRUE;
}    


//Need null terminator at end of string
void UARTPrintROMString(ROM char* StringOChars)
{
    unsigned int ASCIIEncodedByte;
    
    //Make sure the UART module is initialized before trying to use it.
    if(UARTInitialized == FALSE)
    {
        UARTInit();
    }    
    
    while(*StringOChars)
    {
        while(TRMT_BIT == 0u);    //Block until UART transmitter is free
        ASCIIEncodedByte = BYTEtoASCII(*StringOChars++);
        
        TXREG_X = (ASCIIEncodedByte >> 8);   //Print MSB
        TXREG_X = ASCIIEncodedByte;          //Print LSB
    }    
}     

//Need null terminator at end of string
void UARTPrintROMASCIIString(const ROM char* StringOChars)
{
    //Make sure the UART module is initialized before trying to use it.
    if(UARTInitialized == FALSE)
    {
        UARTInit();
    }    

    while(*StringOChars)
    {
        while(TRMT_BIT == 0u);    //Block until UART transmitter is free
        TXREG_X = *StringOChars++;
    }    
}     


void UARTPrintRAMBytes(unsigned char* StringOChars, unsigned char BytesToSend)
{
    unsigned int ASCIIEncodedByte;

    //Make sure the UART module is initialized before trying to use it.
    if(UARTInitialized == FALSE)
    {
        UARTInit();
    }    
    
    while(BytesToSend)
    {
        while(TRMT_BIT == 0u);    //Block until UART transmitter is free
        ASCIIEncodedByte = BYTEtoASCII(*StringOChars++);
        
        TXREG_X = (ASCIIEncodedByte >> 8);   //Print MSB
        TXREG_X = ASCIIEncodedByte;          //Print LSB
        BytesToSend--;
    }    
}     


void UARTPrintRAMASCIIBytes(unsigned char* StringOChars, unsigned char BytesToSend)
{
    //Make sure the UART module is initialized before trying to use it.
    if(UARTInitialized == FALSE)
    {
        UARTInit();
    }    
    
    while(BytesToSend)
    {
        while(TRMT_BIT == 0u);      //Block until UART transmitter is free
        TXREG_X = *StringOChars++;  //Print character
        BytesToSend--;
    }    
}




//Prints a string from RAM.  Requires null terminator at end of StringToPrint char array.
void UARTPrintString(char* StringToPrint)
{
    //Make sure the UART module is initialized before trying to use it.
    if(UARTInitialized == FALSE)
    {
        UARTInit();
    }    
    
    while(*StringToPrint)
    {
        while(TRMT_BIT == 0u);    //Block until UART transmitter is free
        TXREG_X = *StringToPrint++;
    }        
}    

void UARTPrintLineFeedCarriageReturn(void)
{
	char StringToSend[3];

	StringToSend[0] = 0x0A; //Line Feed
	StringToSend[1] = 0x0D; //Carriage Return
	StringToSend[2] = 0x00;	//Null terminator
	
	UARTPrintString((char*)&StringToSend);	
}

void UARTPrintBYTEAsASCIIHex(unsigned char ByteToSend)
{
	unsigned int ASCIIWord;
	char StringToSend[5];

	ASCIIWord = BYTEtoASCII(ByteToSend);
	StringToSend[0] = (unsigned char)(ASCIIWord >> 8);	//High byte
	StringToSend[1] = (unsigned char)(ASCIIWord);		//Low byte
	StringToSend[2] = 0x00;	//Null terminator
	UARTPrintString((char*)&StringToSend);    
}    
	

void UARTPrintWORDAsASCIIHex(unsigned int WordToSend)
{
	unsigned int ASCIIWord;
	char StringToSend[5];

	ASCIIWord = BYTEtoASCII(WordToSend >> 8);
	StringToSend[0] = (unsigned char)(ASCIIWord >> 8);	//High byte
	StringToSend[1] = (unsigned char)(ASCIIWord);		//Low byte

	ASCIIWord = BYTEtoASCII(WordToSend);
	StringToSend[2] = (unsigned char)(ASCIIWord >> 8);	//High byte
	StringToSend[3] = (unsigned char)(ASCIIWord);		//Low byte	

	StringToSend[4] = 0x00;	//Null terminator
	UARTPrintString((char*)&StringToSend);	
}	

unsigned int BYTEtoASCII(unsigned char HexByte)
{
	unsigned char WorkingByte;
	unsigned int ASCIIReturnVal;

	//Conver Low nibble
	WorkingByte = HexByte & 0x0F;
	if(WorkingByte >= 0x0Au)
		WorkingByte += 0x37;
	else
		WorkingByte += 0x30;
	
	//Put ascii encoded representation of low nibble in the return value.
	ASCIIReturnVal = WorkingByte;

	//Convert high nibble
	WorkingByte = (HexByte & 0xF0) >> 4;
	if(WorkingByte >= 0x0Au)
		WorkingByte += 0x37;
	else
		WorkingByte += 0x30;
		
	//Add ascii high nibble value to ascii low nibble value
	ASCIIReturnVal = ((unsigned int)WorkingByte << 8) + ASCIIReturnVal;
	
	return ASCIIReturnVal;
}	

//Call this periodically if you are expecting to receive bytes of data from
//the UART.  It will buffer up the data internally, and return an unsigned int
//equal to the number of bytes that have been received and are awaiting in the
//buffer.
unsigned int UARTReceiveTasks(void)
{
    BYTE ReceivedByte;
   
    //Make sure UART is turned on and ready for use
    if(UARTInitialized == FALSE)
    {
        UARTInit();
    }    
    
    //Check if any byte(s) have arrived and awaiting reading
    while(RECEIVE_BYTE_AVAILABLE_FLAG)
    {
        ReceivedByte = RCREG_X;
        //Make sure we have circular FIFO buffer space, before saving the
        //most recently received byte to the buffer.
        if(BytesInBuffer < UART_RECEIVE_CIRCULAR_BUFFER_DEPTH)
        {
            //Check for write pointer wraparound
            if(pWritePointer >= (&UARTReceiveBuffer[0] + UART_RECEIVE_CIRCULAR_BUFFER_DEPTH))
            {
                pWritePointer = &UARTReceiveBuffer[0];
            }  
            //Save the byte to the circular FIFO buffer
            *pWritePointer++ = ReceivedByte;
            //Increment count of bytes in buffer, so app knows how many it can
            //fetch.
            BytesInBuffer++;  
        }    
        else
        {
            //We have to throw this byte away, since the receive buffer is already
            //full.  Just increment a lost bytes counter, so it can be used
            //for debugging purposes.  Normally, we should never lose a byte.
            //LostDataBytes++;
        }  
    }    
     
    //Check for FIFO overrun error.  If so, must clear it to resume normal receive operations.     
    if(OERR_BIT == 1)
    {
        #if defined(__18CXX)
            //PIC18 devices, you must clear CREN to clear OERR
            CREN_BIT = 0;
            ImprovedNop();
            ImprovedNop();
            CREN_BIT = 1;
            OERR_BIT = 0;   //Shouldn't do anything since read only on existing PIC18 devices, but we'll be redundant redundant in case of future changes
        #else
            //PIC24 devices you just clear the bit
            OERR_BIT = 0;
        #endif
    }      

    
    return BytesInBuffer;    
}     

//If the return value of UARTReceiveTasks() indicates new data available,
//use this function to copy the specified MaxNumBytesToFetch, into the UserBuffer.
//Returns the actual number of bytes fetched (the lesser of MaxNumBytesToFetch or 
//the number that existed in the receive buffer.
unsigned int UARTGetBytes(unsigned char* pUserBuffer, unsigned int MaxNumBytesToFetch)
{
    unsigned int i;
    unsigned int BytesCopied = 0;
    
    UARTReceiveTasks();
    
    if(BytesInBuffer != 0x0000)
    {
        for(i = 0; i < MaxNumBytesToFetch; i++)
        {
            //Check for read pointer wraparound
            if(pReadPointer >= (&UARTReceiveBuffer[0] + UART_RECEIVE_CIRCULAR_BUFFER_DEPTH))
            {
                pReadPointer = &UARTReceiveBuffer[0];
            }    

            //Copy a byte from circular FIFO to the user's read buffer
            if(pUserBuffer != NULL)
            {
                *pUserBuffer++ = *pReadPointer;
            }  
            pReadPointer++;  
            BytesCopied++;

            //Decrement byte count and check if we read everything available.
            BytesInBuffer--;
            if(BytesInBuffer == 0x0000)
            {
                break;
            }    
        }    
    }
    
    return BytesCopied;
}    


//This function assumes at least one byte of UART data is waiting in the buffer
//and returns the value of the byte.
BYTE UARTGetChar(void)
{
    static BYTE DataByte;
    WORD BytesReceived;
    
    BytesReceived = UARTGetBytes(&DataByte, 1);
    
    if(BytesReceived == 1)
        return DataByte;
    else
        return 0;
}    


//This function checks if any UART data bytes have been received and are awaiting
//retrival using the UARTGetChar() or UARTGetBytes() functions.  This function
//returns TRUE if data is available, or FALSE if no data is available.
BOOL UARTIsPressed(void)
{
    //Check if we have received one or more bytes over the UART
    if(UARTReceiveTasks() > 0)
    {
        return TRUE;       
    }    
    
    return FALSE;
}    


//------------------------------------------------------------------------------
//FUNCTION: void UARTFlushReceiveQueue(void)
//Description: Empties the UART receive queue, regardless of what (if anything) 
//was in it previously.
//------------------------------------------------------------------------------
void UARTFlushReceiveQueue(void)
{
    //Keep reading and popping bytes out of the receive FIFO until empty.
    while(UARTReceiveTasks() != 0)
    {
        //Read bytes from the FIFO and throw them away.
        UARTGetBytes(NULL, 65535);
    }    
}    


//------------------------------------------------------------------------------
//FUNCTION: BYTE UARTWaitForAnyKeyPressed(void)
//Description: Throws away any existing data in the UART receive FIFO buffer, 
//and then blocks indefinitely until a new character is received (subsequent to 
//calling this function) over the UART RX pin.  The function then returns the 
//recently received character.
//------------------------------------------------------------------------------
BYTE UARTWaitForAnyKeyPressed(void)
{
    //First make sure the receive queue is empty and no bytes received prior
    //to calling this function are sitting in the queue (so that this function
    //must block until a brand new byte is finally received, chronologically 
    //after this function was called).
    UARTFlushReceiveQueue();    
    
    //Now wait for a new character to be received.
    while(UARTReceiveTasks() == 0);
    //Pop and return the first char in the buffer
    return UARTGetChar();
}
#else
void UARTInit(void){}
void UARTPrintROMString(rom char* StringOChars){}
void UARTPrintROMASCIIString(ROM char* StringOChars){}
void UARTPrintRAMBytes(unsigned char* StringOChars, unsigned char BytesToSend){}
void UARTPrintString(char* StringToPrint){}
void UARTPrintLineFeedCarriageReturn(void){}
void UARTPrintBYTEAsASCIIHex(unsigned char ByteToSend){}
void UARTPrintWORDAsASCIIHex(unsigned int WordToSend){}
unsigned int BYTEtoASCII(unsigned char HexByte){}
#endif //#ifdef __DEBUG_UART



/** EOF main.c ***************************************************************/
