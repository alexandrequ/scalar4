/********************************************************************
 FileName:  PIC18UART_Routines.h
 Dependencies:  See INCLUDES section
 Processor: PIC18 or PIC16 Enhanced Core Microcontrollers
 Hardware:  PIC18 or PIC16 with UART connection
 Complier:  Microchip C18 (for PIC18) or XC8 (for PIC16/PIC18)
 Company:   Microchip Technology, Inc.

 Software License Agreement:

 The software supplied herewith by Microchip Technology Incorporated
 (the "Company") for its PIC(R) Microcontroller is intended and
 supplied to you, the Company�s customer, for use solely and
 exclusively on Microchip PIC Microcontroller products. The
 software is owned by the Company and/or its supplier, and is
 protected under applicable copyright laws. All rights are reserved.
 Any use in violation of the foregoing restrictions may subject the
 user to criminal sanctions under applicable laws, as well as to
 civil liability for the breach of the terms and conditions of this
 license.

 THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,
 WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.

********************************************************************
 File Description:

 Change History:
  Rev   Description
  ----  -----------------------------------------
  1.0   Initial version.
********************************************************************/


#if !defined(__UART_ROUTINES_H)
#define __UART_ROUTINES_H

#include "GenericTypeDefs.h"
#include "Compiler.h"

//------------------------------------------------------------------------------
//Configurable/Modifiable Options and Settings:
//------------------------------------------------------------------------------
#define __DEBUG_UART        //Uncomment to enable UART output for debugging.

#define USE_UART1           //Select which UART module to use.
//#define USE_UART2         //Select which UART module to use.

#define DESIRED_BAUD_RATE   (DWORD)9600

#ifndef CLOCK_FREQ
    #define CLOCK_FREQ     (DWORD)48000000  //Make sure this matches the intended CPU frequency, to ensure the baud rate value is correct.
#endif

#define UART_RECEIVE_CIRCULAR_BUFFER_DEPTH  80

//Make sure these match the actual UART pins being used.
#define TX_TRIS  TRISCbits.TRISC4
#define TX_LAT   LATCbits.LATC4
#define RX_TRIS  TRISCbits.TRISC5
#define mInitRXDigital()  {}
#define mInitUartPPS()  {}



//------------------------------------------------------------------------------
//Public prototypes when __DEBUG_UART is defined
//------------------------------------------------------------------------------
void UARTInit(void);                                //Initializes UART hardware and software state variables
void UARTPrintString(char* StringToPrint);          //Prints a null terminated string from RAM
void UARTPrintROMString(ROM char* StringOChars);    //Prints a null terminated string from ROM, but converts numbers into ASCII hex formatted text first
void UARTPrintROMASCIIString(const ROM char* StringOChars); //Prints a null terminated string from ROM.  No data formatting done.  Inputs must already be ASCII encoded if printing to a terminal program, for proper human readability.
void UARTPrintRAMBytes(unsigned char* StringOChars, unsigned char BytesToSend); //Prints the user specified number of chars from RAM, but converts numbers into ASCII hex formatted text first
void UARTPrintRAMASCIIBytes(unsigned char* StringOChars, unsigned char BytesToSend); //Prints the user specified number of chars from RAM.  No data formatting done.  Input bytes must already be ASCII encoded if printing to a terminal program, for proper human readability.
void UARTPrintBYTEAsASCIIHex(char ByteToSend);   //Converts an unsigned char into an ASCII hex formatted char pair and sends it over the UART
void UARTPrintWORDAsASCIIHex(unsigned int WordToSend);    //Converts a 16-bit unsigned int into an ASCII hex formatted char array and sends it over the UART
void UARTPrintLineFeedCarriageReturn(void);          //Send a carriage return and line feed to the host
unsigned int BYTEtoASCII(unsigned char HexByte);    //Helper function that converts 8-bit hex/binary number into ASCII encoded char pair (ex: 0b11001111 --> "CF")

//Receive APIs
unsigned int UARTReceiveTasks(void);    //Call this periodically, returns number of bytes currently waiting in buffer
unsigned int UARTGetBytes(unsigned char* pUserBuffer, unsigned int MaxNumBytesToFetch); //Call this when reading data out of the circular FIFO.
BOOL UARTIsPressed(void);
BYTE UARTGetChar(void);
void UARTFlushReceiveQueue(void);       //Empties the UART receive queue, regardless of what was in it previously.
BYTE UARTWaitForAnyKeyPressed(void);    //Blocks indefinitely until a character is received over the UART RX pin.  Returns the character.


//------------------------------------------------------------------------------
#endif //end of #if !defined(__UART_ROUTINES_H)
//End of file UART_Routines.h
