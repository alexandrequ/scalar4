/*************************************************
	PRGA_BMA150.h - Setup for MicroChip Demo XL Chip

	Author: J. W. Hartley
	Revision:	13-Apr-10	Initial Edition

	Setup of XL Chip for PRGA Microchip PIC18F Starter Board Level Demo.

***************************************************/

void PRGAInitBma150 (void);

/* end of file */