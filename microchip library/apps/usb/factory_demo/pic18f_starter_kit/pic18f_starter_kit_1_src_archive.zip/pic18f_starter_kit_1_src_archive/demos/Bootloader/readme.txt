The SD-card boot loader provided with this starter kit requires full optimizations
in order to fit in the required sized.  The compiler provided with this starter 
kit will only support optimizations for a limited time.  After that time has expired
this project will no longer compile.  

 

If you can no longer compile this project, the boot loader can be programmed into the
starter kit through the precompiled hex file provided.  This file is located in the 
"<Install Folder>\Bootloader Hex File" folder.  To program this file select "File->Import->Hex"
from the MPLAB window.  Select the appropriate hex file and follow the wizard.
At this point you can program the device with the bootloader.
